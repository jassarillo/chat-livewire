<?php $__env->startSection("contenido"); ?>

<div class="mx-3 my-3">
        
    <div class="row">
        <div class="col-md-6">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("chat-form")->html();
} elseif ($_instance->childHasBeenRendered('EqSNriK')) {
    $componentId = $_instance->getRenderedChildComponentId('EqSNriK');
    $componentTag = $_instance->getRenderedChildComponentTagName('EqSNriK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EqSNriK');
} else {
    $response = \Livewire\Livewire::mount("chat-form");
    $html = $response->html();
    $_instance->logRenderedChild('EqSNriK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <div class="col-md-6">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("chat-list")->html();
} elseif ($_instance->childHasBeenRendered('qKlFkig')) {
    $componentId = $_instance->getRenderedChildComponentId('qKlFkig');
    $componentTag = $_instance->getRenderedChildComponentTagName('qKlFkig');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qKlFkig');
} else {
    $response = \Livewire\Livewire::mount("chat-list");
    $html = $response->html();
    $_instance->logRenderedChild('qKlFkig', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel-chat/resources/views/home/index.blade.php ENDPATH**/ ?>