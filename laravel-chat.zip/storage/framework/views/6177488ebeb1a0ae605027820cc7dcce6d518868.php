<?php $__env->startSection("contenido"); ?>

<div class="mx-3 my-3">
        
    <div class="row">
        <div class="col-md-6">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("chat-form")->html();
} elseif ($_instance->childHasBeenRendered('jCd955Y')) {
    $componentId = $_instance->getRenderedChildComponentId('jCd955Y');
    $componentTag = $_instance->getRenderedChildComponentTagName('jCd955Y');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jCd955Y');
} else {
    $response = \Livewire\Livewire::mount("chat-form");
    $html = $response->html();
    $_instance->logRenderedChild('jCd955Y', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <div class="col-md-6">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("chat-list")->html();
} elseif ($_instance->childHasBeenRendered('CXqPgKr')) {
    $componentId = $_instance->getRenderedChildComponentId('CXqPgKr');
    $componentTag = $_instance->getRenderedChildComponentTagName('CXqPgKr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CXqPgKr');
} else {
    $response = \Livewire\Livewire::mount("chat-list");
    $html = $response->html();
    $_instance->logRenderedChild('CXqPgKr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/laravel-chat/resources/views/home/index.blade.php ENDPATH**/ ?>